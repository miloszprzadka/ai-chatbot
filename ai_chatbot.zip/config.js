const API_URL = "https://ai-chatbot-5hf5.onrender.com";
window.API_URL = API_URL;
